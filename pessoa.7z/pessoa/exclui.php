<?php
    include 'conecta.php';
    $id = $_GET['id'];

    $sql = "DELETE FROM humanO WHERE id = $id";

    if(mysqli_query($conn, $sql)){
        echo "<script language='javascript' type='text/javascript'>
        alert('Registro excluido com sucesso!');
        window.location.href='index.php'
        </script>";     
    }else{

        echo "<script language='javascript' type='text/javascript'>
        alert('Falha ao excluir o registro!');
        window.location.href='index.php'
        </script>";     
    }

?>